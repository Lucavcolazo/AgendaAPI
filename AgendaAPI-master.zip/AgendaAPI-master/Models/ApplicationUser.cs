using Microsoft.AspNetCore.Identity;

namespace AgendaAPI.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}


