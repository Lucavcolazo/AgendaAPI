public class LoginModel
{
    public string Username { get; set; }
    public string Password { get; set; }
}

// Datos que se piden cuando inicia sesion un usuario